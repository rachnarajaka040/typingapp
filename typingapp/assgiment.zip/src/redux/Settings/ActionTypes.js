export const GET_SETTINGS = "GET_SETTINGS";
