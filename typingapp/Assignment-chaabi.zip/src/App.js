import './App.css';
import { Typing } from './Pages/Typing';

function App() {
  return (
    <div >
    <Typing/>
    </div>
  );
}

export default App;
